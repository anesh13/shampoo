<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<link rel="stylesheet" href="main.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<style type="text/css">
.links-to{
	padding-top: 50px;
	margin:20px;
}
</style>
</head>
<body>
	<div>
  <?php
	if(!isset($_SESSION))
{
		session_start();
}
  include_once("headernav.php")
   ?>
</div>
<div class= "links-to">
        <h2 style="display: inline-block; position: relative; padding: 0 0 0 20px; margin: 20px;">All products</h2>
        &nbsp;&nbsp;&nbsp;&nbsp;
        <div style="display: inline-block; position: relative; float: right; margin: 0 80px 0 20px">
          <a href="recents.php">Your recently viewed</a>
          &nbsp;|&nbsp;
          <a href="popular.php">Most visited<a>
        </div>
      </div>
			  <br>
<div class="col-md-12 mainn mainn-raised">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab1" class="tab-pane active">
									<div class="products-slick" data-nav="#slick-nav-1" >
<?php
                    include 'server4.php';


					$product_query = "SELECT * FROM product";
                $run_query = mysqli_query($db,$product_query);
                if(mysqli_num_rows($run_query) > 0){

                    while($row = mysqli_fetch_array($run_query)){
                        $pro_id    = $row['product_id'];
                        $pro_title = $row['product_title'];
                        $pro_price = $row['product_price'];
                        $pro_image = $row['product_image'];


		}
        ;

}
?>
<!-- /product -->
          </div>
          <div id="slick-nav-1" class="products-slick-nav"></div>
        </div>
        <!-- /tab -->
      </div>
    </div>
</div>
<div>
      <div>
        <?php
            // $products = file('all_products.txt');
            $currentUrl = 'https://';
            $currentUrl .= $_SERVER['HTTP_HOST'];
            $currentUrl .= $_SERVER['REQUEST_URI'];
            $indexInURL = strpos($currentUrl, 'index') + 6;
            $index = substr($currentUrl, $indexInURL);
            $index = intval($index);

            require_once 'server4.php';

            // update recents
            $allRecents = array();
            if(isset($_COOKIE['mostRecentProducts'])) {
              $allRecents = unserialize($_COOKIE['mostRecentProducts'], ["allowed_classes" => false]);
            }

            if (($key = array_search($index, $allRecents)) !== false) {
              unset($allRecents[$key]);
            }
            array_unshift($allRecents, $index);
            setcookie("mostRecentProducts", serialize($allRecents), time() + (86400 * 5)); // 5 days

            // update popular products
            $allPopular = [
              1 => 0,
              2 => 0,
              3 => 0,
              4 => 0,
              5 => 0,
              6 => 0,
              7 => 0,
              8 => 0,
              9 => 0,
              10 => 0,
            ];
            if(isset($_COOKIE['mostPopularProducts'])){
              $allPopular = unserialize($_COOKIE['mostPopularProducts'], ['allowed_classes' => false]);
            }
            $allPopular[$index] += 1;
            arsort($allPopular);
            setcookie("mostPopularProducts", serialize($allPopular), time() + (86400 * 5)); // 5 days


            $sql = "SELECT * FROM product WHERE product_id = '$index'";
            $result = mysqli_query($link, $sql);
            $row = mysqli_fetch_assoc($result);

            echo('
              <p class="product-name">'.$row['name'].'</p>
              <div>
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                  <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                  </ol>
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                      <img class="d-block w-100" src="'.$row['img1Url'].'" alt="First slide">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100" src="'.$row['img2Url'].'" alt="Second slide">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100" src="'.$row['img3Url'].'" alt="Third slide">
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
                <div style="width: 50%; float: right">
                  <p style="padding: 20px 0">'.$row['description'].'</p>
                  <a href="" class="btn btn-primary">'.$row['price'].'</a>
                </div>
              </div>
            ');

            mysqli_free_result($result);
            mysqli_close($link);

        ?>
      </div>
    </div>
</body>
</html>
